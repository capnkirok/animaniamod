package com.animania.items;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.GameRegistry;

import com.animania.Animania;

public class ItemOmelette extends ItemFood {
	private String name = "omelette";

	public ItemOmelette(String type) {
		super (5, 5F, true); 
		this.setAlwaysEdible();
		name = type + "_" + name;
		this.setRegistryName(new ResourceLocation(Animania.modid, name));
		GameRegistry.register(this);
		setUnlocalizedName(Animania.modid + "_" + name);
		this.setCreativeTab(Animania.TabAnimaniaResources);
		this.setMaxStackSize(64);
	}
	

	public EnumAction getItemUseAction(ItemStack itemstack) {
		return EnumAction.EAT;
	}

	protected void onFoodEaten(ItemStack itemstack, World worldObj, EntityPlayer entityplayer) {
		if (!worldObj.isRemote && Animania.foodsGiveBonusEffects)
		{
			if (itemstack.getItem() == Animania.cheeseOmelette) {
				entityplayer.addPotionEffect(new PotionEffect(MobEffects.INSTANT_HEALTH, 2, 2, false, false));
			} else if (itemstack.getItem() == Animania.baconOmelette) {
				entityplayer.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 600, 0, false, false));
			} else if (itemstack.getItem() == Animania.truffleOmelette) {
				entityplayer.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 600, 1, false, false));
			} else if (itemstack.getItem() == Animania.ultimateOmelette) {
				entityplayer.addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 600, 1, false, false));
				entityplayer.addPotionEffect(new PotionEffect(MobEffects.STRENGTH, 600, 0, false, false));
				entityplayer.addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 600, 1, false, false));
			}
			
		}
	}
	
	public String getName()
	{
		return name;
	}
	
}
