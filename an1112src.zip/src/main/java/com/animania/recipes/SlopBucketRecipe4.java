package com.animania.recipes;

import java.util.ArrayList;
import java.util.Iterator;

import com.animania.Animania;

import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.NonNullList;
import net.minecraft.world.World;

public class SlopBucketRecipe4 implements IRecipe {
	
	private final ItemStack recipeOutput;
	public final ArrayList recipeItems = new ArrayList();;
	
	public SlopBucketRecipe4()
    {
        this.recipeOutput = new ItemStack(Animania.bucketSlop);
        this.recipeItems.add(new ItemStack(Items.BEETROOT));
        this.recipeItems.add(new ItemStack(Items.BREAD));
        this.recipeItems.add(new ItemStack(Items.MILK_BUCKET));
    }

	@Override
	public boolean matches(InventoryCrafting inv, World world) {
		
        ArrayList arraylist = new ArrayList(this.recipeItems);

        for (int i = 0; i < 3; ++i)
        {
            for (int j = 0; j < 3; ++j)
            {
                ItemStack itemstack = inv.getStackInRowAndColumn(j, i);

                if (itemstack != ItemStack.EMPTY)
                {
                    boolean flag = false;
                    Iterator iterator = arraylist.iterator();

                    while (iterator.hasNext())
                    {
                        ItemStack itemstack1 = (ItemStack)iterator.next();

                        if (itemstack.getItem() == itemstack1.getItem())
                        {
                            flag = true;
                            arraylist.remove(itemstack1);
                            break;
                        }
                    }

                    if (!flag)
                    {
                        return false;
                    }
                }
            }
        }

        return arraylist.isEmpty();
	}
	
	@Override
	public NonNullList<ItemStack> getRemainingItems(InventoryCrafting inv) 
	{ 
		NonNullList<ItemStack> nnlist = NonNullList.<ItemStack>withSize(inv.getSizeInventory(), ItemStack.EMPTY);

		for (int i = 0; i < nnlist.size(); ++i)
		{
			nnlist.set(i, net.minecraftforge.common.ForgeHooks.getContainerItem(inv.getStackInSlot(i)));
		}

		return nnlist;
	}
	

	@Override
	public ItemStack getCraftingResult(InventoryCrafting inv)
	{
		return this.recipeOutput.copy();
	}

	@Override
	public int getRecipeSize()
	{
		return this.recipeItems.size();
	}

	@Override
	public ItemStack getRecipeOutput()
	{		
		return ItemStack.EMPTY;
	}
}


