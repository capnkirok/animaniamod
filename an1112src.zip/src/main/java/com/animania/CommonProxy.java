package com.animania;



public class CommonProxy  {

	public void registerRenderers() {}

	public void registerTextures() {}


}
